# backend/mapping/session_analyzer.py

import asyncio
import logging
from typing import Dict, Optional, Set, AsyncGenerator
from pathlib import Path
from .analysis_session import AnalysisSession
from .entity_processor import EntityProcessor
from graph.graph_manager import CodeGraphManager
from lsp.language_server_manager import LanguageServerManager
from utils.language_detector import LanguageDetector

logger = logging.getLogger(__name__)

class SessionAnalyzer:
    def __init__(self, graph_manager: CodeGraphManager):
        self.graph_manager = graph_manager
        self.lsp_manager = LanguageServerManager()
        self.language_detector = LanguageDetector()
        self.entity_processor = EntityProcessor(self.graph_manager)
        
    async def analyze_codebase_stream(
        self,
        root_path: str,
        project_name: str,
        session_id: str
    ) -> AsyncGenerator[str, None]:
        session = AnalysisSession(session_id, self.graph_manager, root_path)
        
        try:
            # Check existing analysis
            state = await self.graph_manager.get_analysis_state(session_id)
            if state and state["status"] == "completed":
                yield self._format_event('complete', {'message': 'Analysis exists'})
                return

            # Initialize session
            await session.initialize()
            yield self._format_event('initialized', {'session_id': session_id})

            # Process files
            async for event in self.entity_processor.process_files(
                root_path, 
                project_name,
                session
            ):
                yield self._format_event(**event)

            # Create relationships
            yield self._format_event('status', {'message': 'Creating relationships'})
            await self.entity_processor.create_relationships(session)

            # Complete session
            await session.complete()
            yield self._format_event('complete', {'message': 'Analysis completed'})

        except Exception as e:
            logger.error(f"Analysis error: {str(e)}", exc_info=True)
            await session.handle_error(e)
            yield self._format_event('error', {'message': str(e)})
        finally:
            await self.lsp_manager.stop_servers()

    @staticmethod
    def _format_event(event_type: str, data: Dict) -> str:
        import json
        return f"data: {json.dumps({'type': event_type, 'data': data})}\n\n"