from datetime import datetime
from pathlib import Path
from models.analysis import AnalysisStatus, AnalysisState
from graph.graph_manager import CodeGraphManager
from typing import Dict

class AnalysisSession:
    def __init__(self, session_id: str, graph_manager: CodeGraphManager, root_path: str):
        self.session_id = session_id
        self.graph_manager = graph_manager
        self.root_path = root_path
        self.symbol_cache: Dict[str, Dict] = {}
        self.state = AnalysisState(
            session_id=session_id,
            status=AnalysisStatus.INITIALIZED,
            progress=0.0,
            current_file=None,
            total_files=0,
            processed_files=0,
            start_time=datetime.now(),
            last_update=datetime.now()
        )
        
    async def initialize(self) -> None:
        source_files = [f for f in Path(self.root_path).rglob('*') 
                       if f.is_file() and f.suffix in ['.py', '.js', '.php', '.cpp', '.c']]
        self.state.total_files = len(source_files)
        
        await self.graph_manager.update_analysis_state(
            session_id=self.session_id,
            status=self.state.status.value,
            progress=0.0,
            metadata={'root_path': self.root_path, 'total_files': self.state.total_files}
        )
        
    async def update_progress(self, file_path: str) -> None:
        self.state.processed_files += 1
        self.state.current_file = file_path
        self.state.progress = (self.state.processed_files / self.state.total_files) * 100
        self.state.last_update = datetime.now()
        self.state.status = AnalysisStatus.IN_PROGRESS
        
        await self.graph_manager.update_analysis_state(
            session_id=self.session_id,
            status=self.state.status.value,
            progress=self.state.progress,
            metadata={
                'current_file': file_path,
                'processed_files': self.state.processed_files
            }
        )
        
    async def handle_error(self, error: Exception, context: str = None) -> None:
        self.state.status = AnalysisStatus.ERROR
        self.state.error_details = {
            'error_type': error.__class__.__name__,
            'error_message': str(error),
            'context': context or self.state.current_file,
            'timestamp': datetime.now().isoformat()
        }
        
        await self.graph_manager.update_analysis_state(
            session_id=self.session_id,
            status=self.state.status.value,
            progress=self.state.progress,
            metadata={'error_details': self.state.error_details}
        )
        
    async def complete(self) -> None:
        self.state.status = AnalysisStatus.COMPLETED
        self.state.progress = 100.0
        self.state.last_update = datetime.now()
        
        await self.graph_manager.update_analysis_state(
            session_id=self.session_id,
            status=self.state.status.value,
            progress=100.0,
            metadata={
                'completion_time': datetime.now().isoformat(),
                'total_processed': self.state.processed_files
            }
        )