# backend/routes/analysis.py

from fastapi import APIRouter, HTTPException, BackgroundTasks
from fastapi.responses import StreamingResponse
from datetime import datetime
from typing import Dict
from models.analysis import AnalysisStatus
from mapping.session_analyzer import SessionAnalyzer
from graph.graph_manager import CodeGraphManager

router = APIRouter(prefix="/api/analysis", tags=["Analysis"])
graph_manager = CodeGraphManager("bolt://neo4j:7687", "neo4j", "graphydocs")

@router.post("/{project_name}")
async def start_analysis(project_name: str, root_path: str):
    session_id = f"{project_name}_{int(datetime.now().timestamp())}"
    analyzer = SessionAnalyzer(graph_manager)
    
    return StreamingResponse(
        analyzer.analyze_codebase_stream(root_path, project_name, session_id),
        media_type="text/event-stream"
    )

@router.get("/{session_id}/status")
async def get_analysis_status(session_id: str) -> Dict:
    state = await graph_manager.get_analysis_state(session_id)
    if not state:
        raise HTTPException(404, "Analysis session not found")
    return state

@router.post("/{session_id}/cancel")
async def cancel_analysis(session_id: str):
    await graph_manager.update_analysis_state(
        session_id=session_id,
        status=AnalysisStatus.CANCELLED.value,
        progress=0,
        metadata={'cancelled_at': datetime.now().isoformat()}
    )
    return {"message": "Analysis cancelled"}

@router.get("/{session_id}/results")
async def get_analysis_results(session_id: str) -> Dict:
    state = await graph_manager.get_analysis_state(session_id)
    if not state or state["status"] != AnalysisStatus.COMPLETED.value:
        raise HTTPException(404, "Completed analysis not found")
        
    results = await graph_manager.get_analysis_data(session_id)
    return {
        "session_id": session_id,
        "entities": results
    }