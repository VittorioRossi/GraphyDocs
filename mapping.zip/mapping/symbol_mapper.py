from typing import Dict, Optional
from lsp.lsp_symbols import SymbolKind
from graph.models import EntityKind, Location, CodeEntity, Class, Function, Variable, Parameter, Enum

class SymbolMapper:
    KIND_MAPPING = {
        SymbolKind.File: EntityKind.MODULE,
        SymbolKind.Module: EntityKind.MODULE,
        SymbolKind.Namespace: EntityKind.NAMESPACE,
        SymbolKind.Package: EntityKind.MODULE,
        SymbolKind.Class: EntityKind.CLASS,
        SymbolKind.Method: EntityKind.FUNCTION,
        SymbolKind.Function: EntityKind.FUNCTION,
        SymbolKind.Constructor: EntityKind.FUNCTION,
        SymbolKind.Variable: EntityKind.VARIABLE,
        SymbolKind.Constant: EntityKind.VARIABLE,
        SymbolKind.Enum: EntityKind.ENUM,
        SymbolKind.Interface: EntityKind.INTERFACE,
        SymbolKind.Property: EntityKind.VARIABLE,
        SymbolKind.Field: EntityKind.VARIABLE,
        SymbolKind.TypeParameter: EntityKind.PARAMETER
    }

    @classmethod
    def get_entity_kind(cls, symbol_kind: int) -> Optional[EntityKind]:
        return cls.KIND_MAPPING.get(SymbolKind(symbol_kind))

    @classmethod
    def map_symbol_details(cls, symbol: Dict) -> Optional[CodeEntity]:
        kind = cls.get_entity_kind(symbol['kind'])
        if not kind:
            return None

        location = Location(
            file=symbol['location']['uri'].replace('file://', ''),
            start_line=symbol['location']['range']['start']['line'],
            end_line=symbol['location']['range']['end']['line']
        )

        base_attrs = {
            'name': symbol['name'],
            'fully_qualified_name': symbol.get('detail', symbol['name']),
            'kind': kind,
            'location': location
        }

        if kind == EntityKind.CLASS:
            return Class(**base_attrs, is_abstract=False)
        elif kind == EntityKind.FUNCTION:
            return Function(**base_attrs, 
                    return_type=symbol.get('detail', '').split(' -> ')[-1],
                    is_static=False)
        elif kind == EntityKind.VARIABLE:
            return Variable(**base_attrs,
                    type=symbol.get('detail', 'Any'),
                    is_constant=symbol['kind'] == SymbolKind.Constant)
        elif kind == EntityKind.PARAMETER:
            return Parameter(**base_attrs,
                    type=symbol.get('detail', 'Any'))
        elif kind == EntityKind.ENUM:
            return Enum(**base_attrs, values=[])
        else:
            return CodeEntity(**base_attrs)
